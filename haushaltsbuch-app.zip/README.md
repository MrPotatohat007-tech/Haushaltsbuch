# Haushaltsbuch

Android-App, die den CSV-Export der Sparkasse einliest und Ausgaben nach Kategorien sortiert.
Die Daten bleiben auf dem Handy.

Die APK baut GitHub automatisch bei jeder Änderung. Herunterladen unter **Releases → Haushaltsbuch (neueste Version)**.
